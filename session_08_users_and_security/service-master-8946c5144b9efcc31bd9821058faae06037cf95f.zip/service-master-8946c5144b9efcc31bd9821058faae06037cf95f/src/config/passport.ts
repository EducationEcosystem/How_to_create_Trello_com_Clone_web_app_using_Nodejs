import * as passport from 'passport';
import { BasicStrategy } from 'passport-http';

import * as mongoose from 'mongoose';
const User = mongoose.model('User');

passport.use(new BasicStrategy((username: string, password: string, done) => {
    User.findOne({ email: username }, (err, user: any) => {
        if (err) { return done(err); }
        if (!user || !user.validatePassword(password)) {
            return done(null, false);
        }
        done(null, user);
    });
}));

passport.serializeUser((user: any, done) => {
    done(null, user._id);
});

passport.serializeUser((id: string, done) => {
    console.log(id);
    User.findById(id, (err, user) => {
        console.log(err, user);
        done(err, user);
    });
});
