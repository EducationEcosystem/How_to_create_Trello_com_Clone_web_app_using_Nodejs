import * as bodyParser from 'body-parser';
import * as cookieParser from 'cookie-parser';
import * as express from 'express';
import * as session from 'express-session';
import * as logger from 'morgan';
import * as path from 'path';
import * as passport from 'passport';

import './db';
import v1Router from './routes/api.v1';

import './config/passport';
import { register } from './controllers/user.controller';
import { loggedIn } from './config/access';
import { BasicStrategy } from 'passport-http';

const app = express();

if (app.get('env') === 'development') {
    app.use((req, res, next) => {
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Headers', 'content-type,authorization');
        next();
    });
}

app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());

app.use(session({
    cookie: { maxAge: 3600000 },
    secret: 'DONT KEEP THIS IN CODE LIKE HERE',
}));
app.use(passport.initialize());
app.use(passport.session());

app.use(express.static(path.join(__dirname, 'public')));

app.use('/api/v1', loggedIn, v1Router);
app.get('/login', passport.authenticate('basic'), (req, res) => res.sendStatus(204));
app.post('/register', register);

export default app;
