import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';
import 'rxjs/Rx';

const serverURL = 'http://localhost:3000';

@Injectable()
export class RestService {
  constructor(private _http: Http) { }

  executeGet(url: string) {
    return this._http.get(serverURL + url)
      .map(this.extractData)
      .catch(this.handleError);
  }

  extractData(res: Response) {
    return res.json();
  }

  handleError(error: any) {
    return Observable.throw(error);
  }

}
