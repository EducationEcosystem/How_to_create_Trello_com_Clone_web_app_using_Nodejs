import { BrowserModule } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { BoardComponent } from './board/board.component';
import { BoardListComponent } from './board-list/board-list.component';
import { NavbarComponent } from './navbar/navbar.component';

import { MaterialDesignModule } from './material-design/material-design.module';
import { BaseRouterModule } from './base-router/base-router.module';
import { DragulaModule } from 'ng2-dragula';
import { BoardService } from './board/board.service';

@NgModule({
  declarations: [
    AppComponent,
    BoardComponent,
    BoardListComponent,
    NavbarComponent
  ],
  imports: [
    BrowserModule,
    NoopAnimationsModule,
    MaterialDesignModule,
    BaseRouterModule,
    DragulaModule
  ],
  providers: [ BoardService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
